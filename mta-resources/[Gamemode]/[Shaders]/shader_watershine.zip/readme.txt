Resource: Shader Watershine v0.2.1
Author: Ren712
Contact: knoblauch700@o2.pl

update v0.2.1:
-rewritten the resource from scratch
-added shader_dynamic_sky support

This resource works with (but does not require) shader_dynamic_sky:
https://community.multitheftauto.com/index.php?p=resources&s=details&id=6828

This resource applies a light sky colors to get a pseudo-sky-reflection.
The outcome looks better then expected. The effect also creates a 
light sun specular on the water surface. The position of the highlight 
changes during the night and day.


